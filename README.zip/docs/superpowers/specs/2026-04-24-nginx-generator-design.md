# Ngineer Design

## 1. Architecture Overview
The application will be a static Single Page Application (SPA) driven by Vue.js (loaded via CDN) to handle state management and reactivity. 
It consists of three core files:
*   `index.html`: The markup, UI layout, and CDN inclusions.
*   `style.css`: The "Retro-Modern Glassmorphic" design.
*   `app.js`: The Vue instance containing the centralized State Object and the Nginx template generation logic.

## 2. State Management (Vue.js)
The core `data` object will hold all configuration toggles and inputs. Vue's reactivity system will automatically re-render the output block whenever any property changes.

```javascript
data() {
  return {
    domain: 'example.com',
    listen_port: 80,
    https_enabled: false,
    root_dir: '/var/www/html',
    index_files: 'index.html index.htm',
    routing: false, // SPA fallback
    proxy_enabled: false,
    proxy_pass_url: 'http://127.0.0.1:3000',
    websocket_support: false,
    ssl_cert_path: '/etc/ssl/certs/nginx-selfsigned.crt',
    ssl_key_path: '/etc/ssl/private/nginx-selfsigned.key',
    force_https_redirect: false,
    strict_security_headers: true,
    gzip_enabled: true,
    client_max_body_size: '10M',
    static_asset_caching: false
  }
}
```

## 3. Template Engine
A computed property (`generatedConfig`) in the Vue instance will concatenate the Nginx string based on the state. It will handle the conditional logic:
*   Injecting SSL blocks if `https_enabled` is true.
*   Generating a secondary port 80 redirect block if `force_https_redirect` is true.
*   Adding proxy headers and conditional WebSocket support (`Upgrade` headers).
*   Injecting security headers.

## 4. UI/UX Layout (Retro-Modern Glassmorphic)
The layout will use CSS Grid for a responsive two-column design.
*   **Left Column:** A series of glassmorphic "Cards" grouping related settings (Core, Proxy, Security, Performance).
*   **Right Column:** A sticky code block (`<pre><code>`) with custom scrollbars and a "Copy" button using the Clipboard API. Below it, a section showing deployment commands.
*   **Aesthetics:** 
    *   Backgrounds will use `backdrop-filter: blur(10px)` with semi-transparent RGBA colors over an abstract background image or gradient to make the glass effect visible.
    *   Subtle hover transitions (transform/box-shadow).

## 5. Deployment Commands
Another computed property (`deploymentCommands`) will generate the necessary terminal commands to deploy the configuration, utilizing the user-provided `domain` state to construct paths like `/etc/nginx/sites-available/${domain}`.